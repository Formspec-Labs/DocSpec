"""Reader connector for the Mirrulations S3 mirror of regulations.gov.

Wraps the existing S3 discovery + download functions so that one agency's files
for a single :class:`~spicy_docs.schemas.RecordType` are exposed through the
:class:`~spicy_docs.sources.base.Reader` interface. Listing, year-filtering, and
dedup against already-processed keys are delegated to ``list_json_files``;
per-file download + JSON decode is delegated to ``download_and_parse``.

The reader is a *pure source*: it yields the raw JSON payloads. Flattening them
into schema-shaped records is the job of the
:class:`~spicy_regs.transforms.extract.ExtractRecords` transform, which stays
in spicy-regs.
"""

import random
import re
import time
from collections import deque
from collections.abc import Callable, Iterable, Iterator, Sized
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from datetime import datetime
from json import loads
from threading import Lock
from typing import Any

import boto3
from botocore import UNSIGNED
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError, HTTPClientError
from botocore.exceptions import ConnectionError as BotoConnectionError
from loguru import logger
from tqdm import tqdm

from spicy_docs.schemas import RecordType
from spicy_docs.sources.base import Reader

# Connection details for the public Mirrulations mirror live with the source
# that uses them, not in the pipeline.
BUCKET = "mirrulations"
PREFIX = "raw-data"

# Downloads are tiny JSON GETs against S3 — I/O-bound, so a pool of threads per
# agency turns thousands of serial round-trips into concurrent ones. The single
# anonymous resource is shared across the pool: unsigned read-only GetObject has
# no credential-refresh race, and botocore's connection pool is thread-safe.
DEFAULT_DOWNLOAD_WORKERS = 16

# Emit a download-progress line every this many files, so a large agency's
# multi-hour download reports how far along it is (small agencies finish before
# the first mark and just log their staged total).
_PROGRESS_EVERY = 25_000


def s3_resource(max_pool_connections: int = DEFAULT_DOWNLOAD_WORKERS) -> Any:
    """A fresh anonymous S3 resource (one per worker keeps threads independent).

    The connection pool is sized to the download concurrency: botocore defaults
    to 10, but the reader fans GETs across ``DEFAULT_DOWNLOAD_WORKERS`` threads.
    A pool smaller than the thread count oversubscribes — connections churn into
    CLOSE_WAIT and the run stalls — so the pool must be at least the worker count.
    """
    return boto3.resource(
        "s3",
        region_name="us-east-1",
        config=BotoConfig(
            signature_version=UNSIGNED,
            max_pool_connections=max_pool_connections,
            # Bound every S3 op so a stalled connection fails fast and retries
            # instead of wedging a worker indefinitely; standard mode retries
            # transient errors (throttling, resets) rather than dropping records.
            connect_timeout=30,
            # 2026-09-02: 30s read_timeout x 5 standard-mode attempts was not
            # enough -- a four-way fan-out hit 47 `ReadTimeoutError: Read
            # timeout on endpoint URL` failures, each destroying a whole
            # agency's complete-snapshot enumeration in iter_source_objects.
            # 120s covers a full max_bytes object (16 MiB by default) down to
            # ~136 KB/s sustained -- generous enough that a large-but-healthy
            # transfer on a saturated link isn't cut off mid-read and forced
            # to restart, while a truly dead connection still fails within
            # minutes. iter_source_objects's own capped, jittered per-key
            # retry (`_retry_transient`) sits above this and above standard
            # mode's five attempts, not instead of them.
            read_timeout=120,
            retries={"max_attempts": 5, "mode": "standard"},
        ),
    )


def s3_client() -> Any:
    """Anonymous S3 client (used only for agency discovery)."""
    return boto3.client("s3", region_name="us-east-1", config=BotoConfig(signature_version=UNSIGNED))


def get_agencies(s3_client: Any, bucket_name: str, prefix: str) -> list[str]:
    """Get the list of all agencies from the S3 bucket.

    Uses the S3 client directly with ``Delimiter='/'`` to efficiently list
    only top-level folder names without iterating all objects.
    """
    response = s3_client.list_objects_v2(
        Bucket=bucket_name,
        Prefix=f"{prefix}/",
        Delimiter="/",
    )
    agencies = []
    for p in response.get("CommonPrefixes", []):
        agency = p["Prefix"].split("/")[1]
        if agency:
            agencies.append(agency)
    return sorted(agencies)


def iter_json_files(
    s3_resource: Any,
    bucket_name: str,
    prefix: str,
    agency: str,
    data_type: str,
    path_pattern: str,
    processed_keys: Any = None,
    verbose: bool = False,
    since_year: int | None = None,
) -> Iterator[str]:
    """Stream matching agency keys without retaining the whole listing."""
    # Match year from docket ID in path: raw-data/{agency}/{agency}-{YYYY}-...
    year_pattern = re.compile(rf"{re.escape(prefix)}/{re.escape(agency)}/{re.escape(agency)}-(\d{{4}})-")

    matched = 0
    skipped = 0
    filtered_by_year = 0
    total_scanned = 0
    bucket = s3_resource.Bucket(bucket_name)

    for obj in bucket.objects.filter(Prefix=f"{prefix}/{agency}/"):
        key = obj.key
        if "/text-" in key and path_pattern in key and key.endswith(".json"):
            total_scanned += 1
            if since_year:
                m = year_pattern.search(key)
                if m and int(m.group(1)) < since_year:
                    filtered_by_year += 1
                    continue
            if processed_keys and key in processed_keys:
                skipped += 1
                continue
            matched += 1
            yield key

    if verbose:
        year_msg = f", filtered_by_year {filtered_by_year}" if since_year else ""
        tqdm.write(f"    [{agency}] {data_type}: scanned {total_scanned}, skipped {skipped}{year_msg}, new {matched}")


def list_json_files(
    s3_resource: Any,
    bucket_name: str,
    prefix: str,
    agency: str,
    data_type: str,
    path_pattern: str,
    processed_keys: Any = None,
    verbose: bool = False,
    since_year: int | None = None,
) -> list[str]:
    """Materialize matching keys for callers that need a reusable manifest list."""

    return list(
        iter_json_files(
            s3_resource,
            bucket_name,
            prefix,
            agency,
            data_type,
            path_pattern,
            processed_keys,
            verbose,
            since_year,
        )
    )


def list_agency_files_by_type(
    s3_resource: Any,
    bucket_name: str,
    prefix: str,
    agency: str,
    record_types: list[RecordType],
    processed_keys: Any = None,
    verbose: bool = False,
    since_year: int | None = None,
) -> dict[str, list[str]]:
    """List one agency's JSON files in a single pass, bucketed by record type.

    The Mirrulations layout nests every record type under the same agency
    prefix, so calling :func:`list_json_files` once per type re-scans the whole
    (potentially millions of objects) prefix N times. This scans it once and
    classifies each key by which record type's ``path_pattern`` it contains —
    the patterns (``/docket/``, ``/documents/``, ``/comments/``) are mutually
    exclusive, so each key maps to at most one type.
    """
    year_pattern = re.compile(rf"{re.escape(prefix)}/{re.escape(agency)}/{re.escape(agency)}-(\d{{4}})-")
    patterns = [(rt.name, rt.path_pattern) for rt in record_types if rt.path_pattern]
    result: dict[str, list[str]] = {rt.name: [] for rt in record_types}

    bucket = s3_resource.Bucket(bucket_name)
    for obj in bucket.objects.filter(Prefix=f"{prefix}/{agency}/"):
        key = obj.key
        if "/text-" not in key or not key.endswith(".json"):
            continue
        matched = next((name for name, pattern in patterns if pattern in key), None)
        if matched is None:
            continue
        if since_year:
            m = year_pattern.search(key)
            if m and int(m.group(1)) < since_year:
                continue
        if processed_keys and key in processed_keys:
            continue
        result[matched].append(key)

    if verbose:
        summary = ", ".join(f"{name} {len(keys)}" for name, keys in result.items())
        tqdm.write(f"    [{agency}] single-scan listing: {summary}")

    return result


class TransientDownloadError(Exception):
    """S3 GET/read failed (network, throttle) — the key is retryable.

    Raised when the object could not be fetched off S3 at all. The body was
    never (fully) read, so the file may well succeed on a later attempt; the
    caller must therefore *not* record the key as processed, leaving the next
    incremental run free to re-list and re-download it.
    """


class PayloadParseError(Exception):
    """Body downloaded but JSON decode / extract failed — deterministic, not retryable.

    The bytes came off S3 fine; they just don't parse. Re-fetching yields the
    same corrupt payload, so the caller marks the key processed (to stop it
    retrying forever) and logs it for a deliberate replay after a fix.
    """


@dataclass(frozen=True, slots=True)
class DownloadedObject:
    """Exact bytes and source metadata returned by one anonymous S3 GET."""

    content: bytes
    etag: str | None
    version_id: str | None
    last_modified: datetime | None
    content_length: int | None


@dataclass(frozen=True, slots=True)
class MirrulationsSourceObject:
    """One exact listed object, pinned through its source-issued metadata."""

    key: str
    etag: str
    version_id: str | None
    content: bytes


def download_object_bytes(
    s3_resource: Any,
    bucket_name: str,
    key: str,
    *,
    if_match: str | None = None,
    max_bytes: int | None = None,
) -> DownloadedObject:
    """Read one S3 object exactly, optionally pinned to its listed ETag.

    ``IfMatch`` closes the gap between an immutable draw and a later fetch: if
    the mirror replaces an object after listing, S3 refuses the GET instead of
    handing the caller different bytes under the old key.  The response body
    is closed on every path so concurrent batch readers return connections to
    botocore's pool promptly.
    """

    if max_bytes is not None and max_bytes <= 0:
        raise ValueError("max_bytes must be greater than zero")
    obj = s3_resource.Object(bucket_name, key)
    response = obj.get(**({"IfMatch": if_match} if if_match is not None else {}))
    content_length = response.get("ContentLength")
    if max_bytes is not None and content_length is not None and content_length > max_bytes:
        raise ValueError(f"{key} exceeds the {max_bytes} byte cap")
    body = response["Body"]
    try:
        content = body.read(max_bytes + 1) if max_bytes is not None else body.read()
    finally:
        body.close()
    if max_bytes is not None and len(content) > max_bytes:
        raise ValueError(f"{key} exceeds the {max_bytes} byte cap")
    if content_length is not None and content_length != len(content):
        raise ValueError(f"{key} returned {len(content)} bytes but declared {content_length}")
    etag = response.get("ETag")
    if if_match is not None and etag != if_match:
        raise ValueError(f"{key} returned ETag {etag!r}, expected {if_match!r}")
    return DownloadedObject(
        content=content,
        etag=etag,
        version_id=response.get("VersionId"),
        last_modified=response.get("LastModified"),
        content_length=content_length,
    )


# 2026-09-02: a four-way S3 fan-out hit 47 `botocore.exceptions.ReadTimeoutError:
# Read timeout on endpoint URL` failures, and iter_source_objects's fail-fast
# design -- correct for a changed object, a listed-size mismatch, or a
# truncated body, each of which would make the enumeration unfaithful as
# complete-snapshot evidence -- aborted the whole agency for what was only a
# busy network. `download_keys`'s own `transient_retries` retries immediately
# with no backoff; give the exact-enumeration GETs the same patience
# `transport.retry.retry_http` gives the HTTP path: doubling backoff capped
# at 60s, full jitter, 14 attempts (13 possible sleeps) for ~542s (~9 minutes)
# of worst-case patience, so a busy network costs minutes, not an agency.
# Botocore's own standard-mode retries (see `s3_resource`) already ran and
# gave up before any of this is reached -- this sits above them, not instead.
_MAX_TRANSIENT_ATTEMPTS = 14
_TRANSIENT_BACKOFF_CEILING_SECONDS = 60.0


def _is_transient_transport_error(exc: BaseException) -> bool:
    """True only for a genuine transport failure -- the network was busy, not wrong.

    A network-level failure that never got a response at all
    (``botocore.exceptions.ConnectionError`` and its ``EndpointConnectionError``
    / ``ConnectTimeoutError`` / ``SSLError`` subclasses; ``HTTPClientError`` and
    its ``ReadTimeoutError`` / ``ConnectionClosedError`` subclasses -- the exact
    ``ReadTimeoutError`` family behind the 47 failures) or a response that
    explicitly asked for a retry (429, or any 5xx) is worth retrying.

    Everything else is a data fact, not a busy network, and must abort
    immediately: any other ``ClientError`` (404 missing, 403 denied, and
    critically 412 precondition-failed for an object that changed under
    ``IfMatch``), one of ``download_object_bytes``'s own ``ValueError``s
    (missing/changed listing ETag, a listed-size mismatch, an incomplete
    body), or a :class:`PayloadParseError`.
    """
    if isinstance(exc, (BotoConnectionError, HTTPClientError)):
        return True
    if isinstance(exc, ClientError):
        status = exc.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
        return status == 429 or (isinstance(status, int) and status >= 500)
    return False


def _retry_transient[DownloadResult](key: str, operation: Callable[[], DownloadResult]) -> DownloadResult:
    """Run ``operation`` with capped exponential backoff and full jitter.

    Retries only a genuine transient transport failure (see
    :func:`_is_transient_transport_error`); everything else -- including a
    transient failure that has already used up the whole budget -- is
    re-raised immediately, unwrapped, so the caller sees the original
    exception exactly as ``operation`` raised it.

    Full jitter -- a uniform draw between 0 and the deterministic ceiling --
    keeps the pool's workers from retrying in lockstep against the same
    struggling endpoint. Each retry is logged to stderr with the key, the
    attempt number, the chosen delay, and the exception that triggered it, so
    a long retry on a large agency reads as "working" rather than "hung".
    """
    for attempt in range(1, _MAX_TRANSIENT_ATTEMPTS + 1):
        try:
            return operation()
        except Exception as exc:
            if not _is_transient_transport_error(exc) or attempt == _MAX_TRANSIENT_ATTEMPTS:
                raise
            ceiling = min(2**attempt, _TRANSIENT_BACKOFF_CEILING_SECONDS)
            delay = random.uniform(0.0, ceiling)
            logger.warning(
                "{}: retry {}/{} in {:.1f}s (cap {:.0f}s) after {}: {}",
                key,
                attempt,
                _MAX_TRANSIENT_ATTEMPTS - 1,
                delay,
                ceiling,
                type(exc).__name__,
                exc,
            )
            time.sleep(delay)
    raise AssertionError("unreachable")


@dataclass
class DownloadFailures:
    """Per-key download failures, split by whether they're worth retrying.

    ``transient`` keys are excluded from the manifest so the next run retries
    them for free; ``parse`` keys are recorded as processed but surfaced for a
    deliberate replay. A caller that doesn't care passes nothing (the default
    ``failures=None`` on :func:`download_keys` keeps failures uncollected).
    """

    transient: list[str] = field(default_factory=list)
    parse: list[str] = field(default_factory=list)


def download_and_parse(
    s3_resource: Any,
    bucket_name: str,
    key: str,
    extract_fn: Callable[[dict], dict],
) -> dict:
    """Download a single JSON file from S3 and parse it with the given extractor.

    Failures are classified so the caller can retry the retryable ones: a GET or
    read failure raises :class:`TransientDownloadError` (network/throttle — the
    key may succeed next time), while a JSON-decode or extract failure raises
    :class:`PayloadParseError` (the bytes are deterministically bad). Both wrap
    the original exception and carry the offending key.

    The response body is closed on every path — including a failed read — so a
    transient error can't leak the connection into CLOSE_WAIT and starve the
    pool. Leaked connections were the cause of the low-CPU/CLOSE_WAIT hang seen
    on large agencies: once the pool drained, later downloads blocked forever
    waiting for a free connection.
    """
    try:
        content = download_object_bytes(s3_resource, bucket_name, key).content
    except Exception as exc:
        raise TransientDownloadError(key) from exc
    try:
        return extract_fn(loads(content))
    except Exception as exc:
        raise PayloadParseError(key) from exc


def discover_agencies() -> list[str]:
    """List every agency present in the mirror."""
    return get_agencies(s3_client(), BUCKET, PREFIX)


def _identity(payload: dict) -> dict:
    """Decode-only 'extract' — the reader yields raw JSON; flattening is a Transform."""
    return payload


def _record_failure(exc: Exception, key: str, label: str, failures: DownloadFailures | None) -> None:
    """Log a per-key download failure and, when collecting, bucket it by kind.

    Transient failures are surfaced at ``warning`` because they cost a retry;
    parse failures are deterministic corruption the operator may want to replay.
    A ``TransientDownloadError``/``PayloadParseError`` carries its own key, but
    ``key`` is passed explicitly so the caller stays authoritative.
    """
    where = f"{label}: " if label else ""
    if isinstance(exc, PayloadParseError):
        logger.warning("{}parse failure, marking processed: {}", where, key)
        if failures is not None:
            failures.parse.append(key)
    else:
        logger.warning("{}download failed, will retry: {}", where, key)
        if failures is not None:
            failures.transient.append(key)


def download_keys(
    s3_resource: Any,
    bucket_name: str,
    keys: Iterable[str],
    workers: int = DEFAULT_DOWNLOAD_WORKERS,
    *,
    label: str = "",
    failures: DownloadFailures | None = None,
    raise_failures: bool = False,
    transient_retries: int = 0,
) -> Iterator[dict]:
    """Concurrently download + parse the given keys, yielding raw payloads.

    The shared download engine for both :class:`MirrulationsReader` and the
    chunked ingest path. It accepts a key stream and keeps at most twice the
    worker count in flight. Order is not preserved; dedup happens later by key.

    When ``failures`` is provided, each key that couldn't be produced is appended
    to it — transient (retryable) vs. parse (deterministic) — instead of being
    silently dropped, so the caller can exclude the retryable ones from the
    manifest. ``failures=None`` keeps the historical drop-and-continue behavior
    for callers that don't track keys.
    """
    if transient_retries < 0:
        raise ValueError("transient_retries cannot be negative")

    def download(key: str) -> dict:
        for attempt in range(transient_retries + 1):
            try:
                return download_and_parse(s3_resource, bucket_name, key, _identity)
            except TransientDownloadError:
                if attempt == transient_retries:
                    raise
        raise AssertionError("unreachable")

    total = len(keys) if isinstance(keys, Sized) else None
    n = max(1, min(workers, total)) if total is not None and total else max(1, workers)
    if n <= 1:
        for key in keys:
            try:
                yield download(key)
            except (TransientDownloadError, PayloadParseError) as exc:
                _record_failure(exc, key, label, failures)
                if raise_failures:
                    raise
        return

    done = 0
    with ThreadPoolExecutor(max_workers=n) as executor:
        iterator = iter(keys)
        submitted: dict[Future[dict], str] = {}
        exhausted = False
        while submitted or not exhausted:
            while not exhausted and len(submitted) < 2 * n:
                try:
                    key = next(iterator)
                except StopIteration:
                    exhausted = True
                    break
                future = executor.submit(download, key)
                submitted[future] = key
            if not submitted:
                break
            completed, _pending = wait(submitted, return_when=FIRST_COMPLETED)
            for future in completed:
                key = submitted.pop(future)
                done += 1
                if label and done % _PROGRESS_EVERY == 0:
                    logger.info(
                        "{}: downloaded {}{}",
                        label,
                        done,
                        f"/{total}" if total is not None else "",
                    )
                try:
                    yield future.result()
                except (TransientDownloadError, PayloadParseError) as exc:
                    _record_failure(exc, key, label, failures)
                    if raise_failures:
                        raise


_EXHAUSTED = object()


def _bounded_ordered_results(
    executor: ThreadPoolExecutor,
    items: Iterator[Any],
    work: Callable[[Any], Any],
    window: int,
) -> Iterator[tuple[Any, Any]]:
    """Run ``work`` over ``items`` on ``executor``, yielding ``(item, result)``
    in ``items`` order with at most ``window`` futures in flight.

    ``download_keys`` above fans out unordered and doesn't care which key
    finishes first; :meth:`MirrulationsReader.iter_source_objects` is
    complete-snapshot evidence and must preserve listing order and abort on
    the first failure. Popping the window's head and calling ``.result()``
    blocks only on that item, so the failure that aborts is the first *listed*
    one even when a later item failed sooner.

    Once any in-flight future is done with an exception, no further work is
    submitted; leaving this generator — by that failure or by an early close —
    cancels every not-yet-started future. Work already running drains under its
    own timeouts while the caller's executor shuts down.
    """
    pending: deque[tuple[Any, Future[Any]]] = deque()

    def failure_observed() -> bool:
        # Bounded by ``window`` futures, so this stays a constant-factor scan.
        return any(future.done() and future.exception() is not None for _item, future in pending)

    def fill() -> None:
        while len(pending) < window and not failure_observed():
            item = next(items, _EXHAUSTED)
            if item is _EXHAUSTED:
                return
            pending.append((item, executor.submit(work, item)))

    try:
        fill()
        while pending:
            item, future = pending.popleft()
            result = future.result()
            fill()
            yield item, result
    finally:
        for _item, future in pending:
            future.cancel()
        pending.clear()


class MirrulationsReader(Reader):
    """Reads one agency's records of a single record type from Mirrulations S3.

    Yields the raw JSON payload for each file; the keys discovered during the
    most recent ``iter_records`` call are kept on ``last_keys`` so the caller can
    append them to the run manifest.
    """

    def __init__(
        self,
        s3_resource: Any,
        bucket: str,
        prefix: str,
        agency: str,
        record_type: RecordType,
        processed_keys: Any = None,
        since_year: int | None = None,
        verbose: bool = False,
        download_workers: int = DEFAULT_DOWNLOAD_WORKERS,
        key_lister: Callable[[], Iterable[str]] | None = None,
        retain_keys: bool = True,
        fail_fast: bool = False,
    ) -> None:
        self.s3_resource = s3_resource
        self.bucket = bucket
        self.prefix = prefix
        self.agency = agency
        self.record_type = record_type
        self.processed_keys = processed_keys
        self.since_year = since_year
        self.verbose = verbose
        self.download_workers = download_workers
        # When set, supplies this record type's keys (e.g. from a shared
        # single-scan listing); otherwise the reader lists them itself.
        self.key_lister = key_lister
        self.retain_keys = retain_keys
        self.fail_fast = fail_fast
        super().__init__()
        # Parse failures are recorded separately from the base failed_keys,
        # which this reader uses for transient failures eligible for retry.
        self.parse_failed_keys: list[str] = []

    def iter_source_objects(
        self,
        *,
        max_bytes: int = 16 * 1024 * 1024,
    ) -> Iterator[MirrulationsSourceObject]:
        """Capture exact listing membership and ETag-pinned object bytes.

        This path is deliberately fail-fast for anything that would make the
        enumeration unusable as complete-snapshot evidence: a missing listing
        ETag, a changed object, a listed-size mismatch, or an incomplete body
        all abort the enumeration immediately, with no retry. A genuine
        transient transport failure (a read timeout, a connection reset, a
        429/5xx) is not one of those -- the network was busy, not wrong -- so
        each per-key GET gets its own patient, jittered retry
        (:func:`_retry_transient`) before it is allowed to abort the run; see
        the module comment above ``_MAX_TRANSIENT_ATTEMPTS`` for the budget
        and the incident that set it. Listing stays serial (the strict-
        ascending-key assert needs it), but GETs fan out over a thread pool
        bounded to ``self.download_workers`` in flight via
        :func:`_bounded_ordered_results`, and are yielded back in listing
        order regardless of which GET completes first.
        """

        if self.record_type.path_pattern is None:
            raise ValueError(
                f"MirrulationsReader requires a path-addressable record type, "
                f"but {self.record_type.name!r} has no path_pattern."
            )
        if self.processed_keys:
            raise ValueError("complete Mirrulations enumeration cannot omit processed keys")
        year_pattern = re.compile(
            rf"{re.escape(self.prefix)}/{re.escape(self.agency)}/"
            rf"{re.escape(self.agency)}-(\d{{4}})-"
        )
        bucket = self.s3_resource.Bucket(self.bucket)

        def listed_entries() -> Iterator[tuple[str, str, int | None]]:
            previous_key: str | None = None
            for summary in bucket.objects.filter(Prefix=f"{self.prefix}/{self.agency}/"):
                key = summary.key
                if "/text-" not in key or self.record_type.path_pattern not in key or not key.endswith(".json"):
                    continue
                if self.since_year:
                    match = year_pattern.search(key)
                    if match and int(match.group(1)) < self.since_year:
                        continue
                if previous_key is not None and key <= previous_key:
                    raise ValueError("Mirrulations listing keys are not strictly ordered")
                previous_key = key
                etag = getattr(summary, "e_tag", None)
                if not isinstance(etag, str) or not etag:
                    raise ValueError(f"Mirrulations listing lacks an ETag for {key}")
                listed_size = getattr(summary, "size", None)
                if listed_size is not None and (
                    isinstance(listed_size, bool) or not isinstance(listed_size, int) or listed_size < 0
                ):
                    raise ValueError(f"Mirrulations listing size is invalid for {key}")
                yield key, etag, listed_size

        def get(entry: tuple[str, str, int | None]) -> DownloadedObject:
            key, etag, _listed_size = entry
            return _retry_transient(
                key,
                lambda: download_object_bytes(self.s3_resource, self.bucket, key, if_match=etag, max_bytes=max_bytes),
            )

        workers = max(1, self.download_workers)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            for (key, etag, listed_size), downloaded in _bounded_ordered_results(
                executor, listed_entries(), get, workers
            ):
                if listed_size is not None and listed_size != len(downloaded.content):
                    raise ValueError(f"Mirrulations listed size differs from bytes for {key}")
                yield MirrulationsSourceObject(
                    key=key,
                    etag=etag,
                    version_id=downloaded.version_id,
                    content=downloaded.content,
                )

    def iter_records(self) -> Iterator[dict]:
        if self.record_type.path_pattern is None:
            raise ValueError(
                f"MirrulationsReader requires a path-addressable record type, "
                f"but {self.record_type.name!r} has no path_pattern."
            )
        if self.key_lister is not None:
            keys = self.key_lister()
        else:
            keys = list_json_files(
                self.s3_resource,
                self.bucket,
                self.prefix,
                self.agency,
                self.record_type.name,
                self.record_type.path_pattern,
                self.processed_keys,
                self.verbose,
                self.since_year,
            )
        if self.retain_keys:
            keys = list(keys)
            # Populate immediately so manifest callers see the full listing.
            self.last_keys = list(keys)
        else:
            self.last_keys = []

        # Fan the per-file GETs across a thread pool via the shared engine —
        # independent, I/O-bound round trips; order is irrelevant (dedup by key).
        label = f"[{self.agency}] {self.record_type.name}"
        failures = DownloadFailures()
        yield from download_keys(
            self.s3_resource,
            self.bucket,
            keys,
            self.download_workers,
            label=label,
            failures=failures,
            raise_failures=self.fail_fast,
            transient_retries=1 if self.fail_fast else 0,
        )
        # One in-run retry pass over transient failures; whatever still fails is
        # left out of last_keys so the next incremental run re-lists it for free.
        if failures.transient and not self.fail_fast:
            retry = DownloadFailures()
            yield from download_keys(
                self.s3_resource,
                self.bucket,
                list(failures.transient),
                self.download_workers,
                label=f"{label} retry",
                failures=retry,
            )
            failures.transient = retry.transient
            failures.parse.extend(retry.parse)

        self.failed_keys = list(failures.transient)
        self.parse_failed_keys = list(failures.parse)
        # Transient failures are excluded (retried next run); parse failures stay
        # marked processed — a deterministically corrupt file would retry forever.
        if self.retain_keys:
            dropped = set(failures.transient)
            self.last_keys = [k for k in keys if k not in dropped]


class _AgencyListingCache:
    """Memoizes one single-scan listing per agency, shared across its readers.

    ``stage_agencies`` builds a reader per (agency, record type) and runs an
    agency's record types sequentially within one worker thread, so the first
    default reader for an agency triggers the scan and the rest read from the
    cache. Bounded readers bypass this cache and stream their matching keys.
    """

    def __init__(
        self,
        record_types: list[RecordType],
        *,
        processed_keys: Any,
        since_year: int | None,
        verbose: bool,
    ) -> None:
        self._record_types = record_types
        self._processed_keys = processed_keys
        self._since_year = since_year
        self._verbose = verbose
        self._by_agency: dict[str, dict[str, list[str]]] = {}
        self._lock = Lock()

    def keys_for(self, s3_resource: Any, agency: str, record_type: RecordType) -> list[str]:
        with self._lock:
            listed = self._by_agency.get(agency)
        if listed is None:
            scanned = list_agency_files_by_type(
                s3_resource,
                BUCKET,
                PREFIX,
                agency,
                self._record_types,
                processed_keys=self._processed_keys,
                verbose=self._verbose,
                since_year=self._since_year,
            )
            with self._lock:
                listed = self._by_agency.setdefault(agency, scanned)
        return listed.get(record_type.name, [])


def reader_factory(
    record_types: list[RecordType],
    *,
    processed_keys: Any = None,
    since_year: int | None = None,
    verbose: bool = False,
    download_workers: int = DEFAULT_DOWNLOAD_WORKERS,
    resource_factory: Callable[[], Any] | None = None,
    bounded: bool = False,
) -> Callable[[str, RecordType], MirrulationsReader]:
    """Build a ``read(agency, record_type) -> MirrulationsReader`` factory.

    The shared options (manifest membership test, year filter, verbosity) are
    bound once; the caller supplies the agency and record type. Default readers
    cache one reusable agency listing for manifest-producing ingest. With
    ``bounded=True``, a reader streams keys, keeps bounded downloads in flight,
    retries a transient failure once, and then fails closed without retaining a
    manifest list. Each reader gets its own S3 resource.
    """
    cache = (
        None
        if bounded
        else _AgencyListingCache(
            record_types,
            processed_keys=processed_keys,
            since_year=since_year,
            verbose=verbose,
        )
    )
    # Resolve at call time (not as a default arg) so a monkeypatched
    # ``mirrulations.s3_resource`` is honored, and each reader still gets its
    # own resource — safe to call from the staging worker threads. ``s3_resource``
    # sizes its connection pool to ``DEFAULT_DOWNLOAD_WORKERS``, which matches the
    # reader's default ``download_workers`` so the pool is never oversubscribed.
    make_resource = resource_factory or s3_resource

    def read(agency: str, record_type: RecordType) -> MirrulationsReader:
        resource = make_resource()
        if bounded:
            path_pattern = record_type.path_pattern
            if path_pattern is None:
                raise ValueError(f"{record_type.name!r} has no Mirrulations path pattern")

            def list_keys() -> Iterable[str]:
                return iter_json_files(
                    resource,
                    BUCKET,
                    PREFIX,
                    agency,
                    record_type.name,
                    path_pattern,
                    processed_keys,
                    verbose,
                    since_year,
                )

        else:
            assert cache is not None

            def list_keys() -> Iterable[str]:
                return cache.keys_for(resource, agency, record_type)

        return MirrulationsReader(
            resource,
            BUCKET,
            PREFIX,
            agency,
            record_type,
            processed_keys=processed_keys,
            since_year=since_year,
            verbose=verbose,
            download_workers=download_workers,
            key_lister=list_keys,
            retain_keys=not bounded,
            fail_fast=bounded,
        )

    return read
